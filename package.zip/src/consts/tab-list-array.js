export const tabListArray = [{
    'nameRu': 'Булки',
    'name':'bun'},
  {
    'nameRu': 'Соусы',
    'name':'sauce'},
  {
    'nameRu': 'Начинки',
    'name':'main'
  }
];

