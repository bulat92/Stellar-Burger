import { InnerIngredientView } from '../components/inner-ingredient-view/inner-ingredient-view';

export const IngredientView = () => {
  return (
    <>
      <InnerIngredientView />
    </>
  );
};
