import {ProfileInner} from '../components/inner-profile/inner-profile'
 
export const Profile = () => {
 
  return (
    <>
      <ProfileInner />
    </>
  );
};
